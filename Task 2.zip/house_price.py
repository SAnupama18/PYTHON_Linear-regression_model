import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score, mean_squared_error
import matplotlib.pyplot as plt

# Load dataset
df = pd.read_csv("house.csv")

# Features (all columns except MEDV)
X = df.drop("MEDV", axis=1)

# Target (House Price)
y = df["MEDV"]

# Split dataset
X_train, X_test, y_train, y_test = train_test_split(
    X, y,
    test_size=0.2,
    random_state=42
)

# Train model
model = LinearRegression()
model.fit(X_train, y_train)

# Predictions
predictions = model.predict(X_test)

# Accuracy
r2 = r2_score(y_test, predictions)
mse = mean_squared_error(y_test, predictions)

print("R2 Score:", r2)
print("Mean Squared Error:", mse)

# Show first 5 predictions
print("\nSample Predictions:")
for i in range(5):
    print(f"Actual: {y_test.iloc[i]:.2f}  Predicted: {predictions[i]:.2f}")

# Graph
plt.scatter(y_test, predictions)
plt.xlabel("Actual Price")
plt.ylabel("Predicted Price")
plt.title("House Price Prediction")
plt.show()